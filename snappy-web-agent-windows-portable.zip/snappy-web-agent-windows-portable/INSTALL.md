# Snappy Web Agent - Portable Windows Installation

## Quick Start

1. **Extract** this folder to your desired location (e.g., `C:\SnappyWebAgent\`)
2. **Run as Administrator** - Right-click `install-service.bat` and select "Run as administrator"
3. **Start the service** using `start-service.bat`

## Files Included

- `snappy-web-agent.exe` - Main application
- `service-manager.bat` - Service management script
- `install-service.bat` - Quick installation script
- `start-service.bat` - Start service script
- `stop-service.bat` - Stop service script
- `uninstall-service.bat` - Uninstall service script
- `README.md` - Project documentation
- `LICENSE.rtf` - License information

## Manual Installation

### Install as Windows Service

```batch
# Install service (Run as Administrator)
service-manager.bat install

# Start service
service-manager.bat start

# Check service status
sc query SnappyWebAgent
```

### Uninstall Service

```batch
# Stop and uninstall service (Run as Administrator)
service-manager.bat stop
service-manager.bat uninstall
```

## Service Management

The service will:
- Automatically start on system boot
- Listen on ports 8436-8535 (finds first available)
- Log to Windows Event Viewer
- Automatically restart if it crashes

## Firewall

If you need to access from other computers:
1. Open Windows Firewall
2. Add inbound rule for ports 8436-8535 (TCP)

## Troubleshooting

**Service won't start:**
1. Run Command Prompt as Administrator
2. Navigate to the installation folder
3. Run: `snappy-web-agent.exe` directly to see error messages

**Port conflicts:**
- Check which ports are in use: `netstat -an | findstr :843`
- Stop other applications using those ports

**Permissions:**
- Ensure you're running as Administrator for service operations
- The executable needs access to USB/Serial ports

## Support

- GitHub: https://github.com/gouthamsk98/snappy-web-agent
- Issues: Report problems on GitHub Issues

